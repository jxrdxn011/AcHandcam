--[[
  AcHandCam - drives Assetto Corsa's camera from a phone (ARKit / ARCore) pose.

  Data path: phone --UDP--> PC receiver (Python) --shared memory--> this app
  --> AC's free camera (F7), moved every update like the Drone Camera mod does.

  v2: phone zoom -> FOV, walk mode (shutter joystick), terrain following,
  left/right measured from the car's wheels, side vector computed by CSP.
  v3: writes a small "view" block (current FOV, smoothing, live flag) that the
  receiver needs to timewarp the live view on the phone.

  CSP APIs used (all from the public CSP Lua SDK, github.com/ac-custom-shaders-patch/acc-lua-sdk):
    ac.setCurrentCamera(mode), ac.setCameraPosition(pos), ac.setCameraDirection(look, up), ac.setCameraFOV(fov)
    ac.readMemoryMappedFile(name, layout) / ac.writeMemoryMappedFile(name, layout)
    ac.getSim() {cameraPosition, cameraLook, cameraUp, focusedCar}
    ac.getCar(i) {position, look, wheels[0..3].position}
    physics.raycastTrack(pos, dir, length) -> distance or -1
    ac.storage(defaults), ac.ControlButton(id, defaults), ui.*
]]

local hc = require('src/hcmath')

local POSE_NAME = 'AcTools.CSP.Limited.HandheldCam.Pose'
local STATUS_NAME = 'AcTools.CSP.Limited.HandheldCam.Status'
local VIEW_NAME = 'AcTools.CSP.Limited.HandheldCam.View'
local RECEIVER_TIMEOUT = 1.0 -- s without a new heartbeat = receiver not running
local STICK_TIMEOUT = 0.3 -- s without fresh data = treat the joystick as released
local MIN_CLEARANCE = 0.15 -- m: the camera never goes closer than this to the ground

local cfg = ac.storage({
  fov = 46.0, -- vertical FOV at 1x zoom; 46 deg ~ iPhone main camera in 16:9 video
  zoomFromPhone = true, -- use the phone's zoom
  smoothing = 0.03, -- render-side smoothing time constant (s); 0 = none
  blendTime = 0.4, -- engage/release hand-over time (s)
  followCar = false, -- camera rides with the focused car (in-car / chase-car shots)
  followTilt = true, -- follow-car: also pitch/roll with the car (rigidly mounted)
  followSource = 2, -- follow-car car pose: 2 = drawn body, 3 = physics pose
  handedness = 1, -- 1 auto (from the car's wheels), 2 normal, 3 mirrored
  lookOverride = 0, -- 0 auto-detect, -1 force reversed
  walkSpeed = 1.6, -- m/s at full stick
  walkSmoothing = 0.35, -- s: how gently walking starts (stopping is a bit quicker)
  headBob = 1.0, -- walk mode head bob: 0 off, 1 subtle, 2 strong
  terrainAlways = false, -- also keep the camera above ground in handheld mode
}, 'v2.')

-- ------------------------------------------------------------------ state
local pose = nil -- shared memory from the receiver (cdata) or nil
local poseRetry = 0
local status = nil
local statusOk, statusErr = pcall(function() status = ac.writeMemoryMappedFile(STATUS_NAME, hc.STATUS_LAYOUT) end)
if not statusOk then ac.log('AcHandCam: status MMF unavailable: ' .. tostring(statusErr)) end
local view = nil
local viewOk, viewErr = pcall(function() view = ac.writeMemoryMappedFile(VIEW_NAME, hc.VIEW_LAYOUT) end)
if not viewOk then ac.log('AcHandCam: view MMF unavailable: ' .. tostring(viewErr)) end
local viewFrame = 0
local effectiveSmoothing = 0
local renderHb, renderRot = nil, nil -- live view: pose heartbeat and target->shown rotation of this frame

local cam = nil -- the free-camera driver while engaged (see newFreeCamera)
local phase = 'idle' -- idle | probe | in | live | out
local probeFrames = 0
local lookSign, sideObserved = 1, 0
local share = 0
local anchor, anchor0 = nil, nil -- in rig-frame coordinates (see hcmath "rig frames")
local rigF, rigMode = hc.WORLD, nil -- current rig frame: the world, or the focused car
local needAnchor = true
local lastGeneration = -1
local frozen = false
local sample = nil -- last valid sample {p,f,u,state,zoom,joy...}
local lastHeartbeat, heartbeatAge = -1, 99
local cur = nil -- currently applied {pos, look, up}
local curFov = nil
local errorText, errorCode = '', 0
local appliedCount, fps = 0, 60
local tempSmoothing, tempSmoothingTime = nil, 0
local heartbeatOut = 0
local recenterRequests = 0 -- the receiver recenters when this changes
local detectedMirror = nil -- from the car's wheels; nil = unknown
local groundPrev = nil -- filtered ground height under the camera, last frame
local groundRaw = nil
local terrainWasActive = false
local walking = false
local walkVel = { x = 0, y = 0, z = 0 } -- smoothed walking velocity (world, m/s)
local bobPhase = 0

local hasRaycast = type(physics) == 'table' and type(physics.raycastTrack) == 'function'

local function vec(v3) return hc.v(v3.x, v3.y, v3.z) end

local function setError(code, text)
  errorCode, errorText = code, text or ''
  if text and text ~= '' then ac.log('AcHandCam: ' .. text) end
end

local function mirror()
  if cfg.handedness == 2 then return false end
  if cfg.handedness == 3 then return true end
  return detectedMirror == true
end

local function raycast(p, d, len)
  return physics.raycastTrack(vec3(p.x, p.y, p.z), vec3(d.x, d.y, d.z), len)
end

-- ------------------------------------------------------------ shared memory
local function openPose()
  local ok, res = pcall(ac.readMemoryMappedFile, POSE_NAME, hc.POSE_LAYOUT)
  if ok and res then
    pose = res
  else
    pose = nil
  end
end

local function readSample()
  if not pose then return nil end
  local e = pose.seqEnd
  local s = {
    magic = pose.magic, version = pose.version, heartbeat = pose.heartbeat,
    state = pose.outState, flags = pose.flags, generation = pose.generation,
    tracking = pose.trackingState,
    p = hc.v(pose.px, pose.py, pose.pz),
    f = hc.v(pose.fx, pose.fy, pose.fz),
    u = hc.v(pose.ux, pose.uy, pose.uz),
    latency = pose.latencyMs, rxHz = pose.rxHz, loss = pose.lossPct,
    zoom = pose.zoom, joyX = pose.joyX, joyY = pose.joyY, mode = pose.mode,
    viewOrientation = pose.viewOrientation, vfAspect = pose.vfAspect,
  }
  local b = pose.seqBegin
  if b ~= e or s.magic ~= hc.POSE_MAGIC or s.version ~= hc.POSE_LAYOUT_VERSION then return nil end
  if not (s.zoom == s.zoom and s.zoom > 0) then s.zoom = 1 end
  if not (s.joyX == s.joyX and s.joyY == s.joyY) then s.joyX, s.joyY = 0, 0 end
  if s.state == 0 or not hc.validSample(s) then return s, false end
  return s, true
end

-- ------------------------------------------------------------------- camera
local function focusedCar()
  local sim = ac.getSim()
  local idx = sim.focusedCar
  if not idx or idx < 0 then return nil end
  return ac.getCar(idx)
end

local function focusedCarPose()
  local car = focusedCar()
  if not car then return nil end
  return vec(car.position), vec(car.look)
end

-- The frame everything is anchored in this frame: the world, or the focused
-- car's own frame (follow-car): its drawn body transform.

local function bodyFrame(car)
  -- the car's visual transform (what is drawn), or with source 3 the physics pose
  local ok, p, l, u = pcall(function()
    if cfg.followSource == 3 then error('physics pose wanted') end
    local t = car.bodyTransform
    return vec(t.position), vec(t.look), vec(t.up)
  end)
  if not (ok and p and hc.len(l) > 0.5 and hc.len(u) > 0.5) then
    p, l = vec(car.position), vec(car.look)
    local okU, uu = pcall(function() return vec(car.up) end)
    u = (okU and uu and hc.len(uu) > 0.5) and uu or hc.Y
  end
  local look, up = l, u
  if not cfg.followTilt then
    look = hc.headingOf(l, u)
    up = hc.Y
  end
  return hc.frame(p, look, up)
end

local function currentRig()
  if not cfg.followCar then return hc.WORLD, 'world' end
  local car = focusedCar()
  if not car then return hc.WORLD, 'world' end
  return bodyFrame(car), 'car'
end

local function cameraModeNow()
  local ok, m = pcall(function() return ac.getSim().cameraMode end)
  return ok and m or nil
end

-- Aspect ratio of the AC window (the captured picture), for the lens model.
local function gameAspect()
  local ok, a = pcall(function()
    local w = ac.getUI().windowSize
    return w.x / w.y
  end)
  if ok and a and a == a and a > 0.2 and a < 10 then return a end
  return 16 / 9
end

-- Physically measure which way "right" is: front-right minus front-left wheel.
local function detectHandedness()
  local ok, res = pcall(function()
    local car = focusedCar()
    if not car or not car.wheels then return nil end
    return hc.mirrorFromWheels(vec(car.look), vec(car.wheels[0].position), vec(car.wheels[1].position))
  end)
  if ok and res ~= nil then
    detectedMirror = res
    ac.log('AcHandCam: left/right measured from car wheels: ' .. (res and 'mirrored' or 'normal'))
  end
end

-- 4.4: the Drone Camera way. Instead of a CSP script camera (whose transform
-- is "applied with the next frame", so anything parented to a moving car
-- trails it by a frame and shakes with the frame time), AC is switched to its
-- own free camera (F7) and that camera is moved directly every update - the
-- same functions the Drone Camera mod uses, which follows cars perfectly.
-- This object looks like an ac.GrabbedCamera to the rest of the app: ownShare
-- blends between the view AC had when you engaged and ours.
local function newFreeCamera()
  local sim = ac.getSim()
  local function v3(t) return { x = t.x, y = t.y, z = t.z, set = function(self, x, y, z) self.x, self.y, self.z = x, y, z end } end
  local okF, fov0 = pcall(function() return ac.getCameraFOV() end)
  local o = {
    position = v3(vec(sim.cameraPosition)), look = v3(vec(sim.cameraLook)), up = v3(vec(sim.cameraUp)),
    side = v3(hc.cross(vec(sim.cameraUp), vec(sim.cameraLook))),
  }
  local f = {
    free = true, ownShare = 0, disposed = false, frames = 0, prevMode = sim.cameraMode,
    fovOriginal = (okF and type(fov0) == 'number' and fov0 > 1) and fov0 or cfg.fov,
    transformOriginal = o,
    transform = { position = v3(o.position), look = v3(o.look), up = v3(o.up), side = v3(o.side) },
  }
  f.fov = f.fovOriginal
  function f:active()
    if self.disposed then return false end
    if self.frames < 10 then return true end -- AC may take a frame or two to switch
    local okM, m = pcall(function() return ac.getSim().cameraMode end)
    return not okM or m == nil or m == ac.CameraMode.Free
  end
  function f:normalize()
    local l, u = hc.orthonormal(vec(self.transform.look), vec(self.transform.up))
    local r = hc.cross(u, l)
    self.transform.look:set(l.x, l.y, l.z)
    self.transform.up:set(u.x, u.y, u.z)
    self.transform.side:set(r.x, r.y, r.z)
  end
  function f:flush()
    if self.disposed then return end
    self.frames = self.frames + 1
    local s, t, og = math.min(1, math.max(0, self.ownShare)), self.transform, self.transformOriginal
    local p = hc.lerp(vec(og.position), vec(t.position), s)
    local l = hc.normalize(hc.lerp(vec(og.look), vec(t.look), s), vec(t.look))
    local u = hc.normalize(hc.lerp(vec(og.up), vec(t.up), s), vec(t.up))
    pcall(function()
      ac.setCameraPosition(vec3(p.x, p.y, p.z))
      ac.setCameraDirection(vec3(l.x, l.y, l.z), vec3(u.x, u.y, u.z))
      ac.setCameraFOV(self.fovOriginal + (self.fov - self.fovOriginal) * s)
    end)
  end
  function f:dispose()
    if self.disposed then return end
    self.disposed = true
    pcall(function()
      if self.prevMode ~= nil and self.prevMode ~= ac.CameraMode.Free then ac.setCurrentCamera(self.prevMode) end
    end)
  end
  -- start exactly where AC's camera is, then switch to the free camera
  f:flush()
  f.frames = 0
  local ok = pcall(function() ac.setCurrentCamera(ac.CameraMode.Free) end)
  if not ok or type(ac.setCameraPosition) ~= 'function' then return nil, 'free camera control not available' end
  f:flush()
  f.frames = 0
  return f
end

local function engage()
  if cam then return end
  local c, err = newFreeCamera()
  if not c then
    setError(1, 'Could not take the camera: ' .. tostring(err) .. ' (update Custom Shaders Patch)')
    ac.setMessage('AcHandCam', 'Could not take the camera: ' .. tostring(err))
    return
  end
  cam = c
  cam.ownShare = 0
  share = 0
  phase = 'probe'
  probeFrames = 0
  walkVel, bobPhase = hc.v(0, 0, 0), 0
  needAnchor = true
  anchor0 = nil
  rigF, rigMode = hc.WORLD, nil
  frozen = false
  curFov = nil
  detectHandedness()
  setError(0, '')
  ac.log('AcHandCam: free camera engaged')
end

local function releaseNow()
  if cam then
    pcall(function() cam:dispose() end)
    ac.log('AcHandCam: camera released')
  end
  cam, phase, share, cur, curFov = nil, 'idle', 0, nil, nil
  walking = false
  walkVel, bobPhase = hc.v(0, 0, 0), 0
end

-- Release: AC's own camera comes back as it is now (blending back to the
-- view from when you engaged would fly off a moving car).
local function disengage()
  if cam then releaseNow() end
end

-- Ask the receiver to recenter (same as the phone's Recenter button). The
-- receiver bumps the generation, so this app re-anchors and the view stays put.
local function requestRecenter() recenterRequests = (recenterRequests + 1) % 4294967296 end

local function resetToStart()
  if anchor0 then
    if anchor0.mode ~= rigMode then return end -- started in the other mode
    anchor = { pos = anchor0.pos, fwd = anchor0.fwd }
    groundPrev = nil
    tempSmoothing, tempSmoothingTime = 0.35, 1.5 -- glide back instead of cutting
  end
end

-- Detect the look-vector convention while AC still renders its own camera.
-- Retries for a few frames in case transformOriginal isn't filled in yet.
local function probeConventions()
  local sim = ac.getSim()
  local look0 = vec(cam.transformOriginal.look)
  if hc.len(look0) < 0.5 then return false end
  local d = hc.dot(hc.normalize(look0, hc.v(0, 0, 1)), vec(sim.cameraLook))
  if math.abs(d) <= 0.5 then return false end
  lookSign = d > 0 and 1 or -1
  return true
end

-- Move the anchor by a rig-frame delta (walking, terrain).
local function moveAnchor(delta)
  anchor.pos = hc.add(anchor.pos, delta)
end

local function buildAnchor(s)
  local cp, cl, cu
  if cur then
    cp, cl, cu = cur.pos, cur.look, cur.up
  else -- AC's own camera, brought into the rig frame
    cp = hc.worldToFrame(rigF, vec(ac.getSim().cameraPosition))
    cl = hc.worldToFrameDir(rigF, vec(ac.getSim().cameraLook))
    cu = hc.worldToFrameDir(rigF, vec(ac.getSim().cameraUp))
  end
  anchor = hc.makeAnchor(cp, cl, cu, s, mirror())
  if not anchor0 then anchor0 = { pos = anchor.pos, fwd = anchor.fwd, mode = rigMode } end
  groundPrev = nil -- re-measure the ground from here
  needAnchor = false
end

local function walkMode() return sample ~= nil and sample.mode == hc.MODE_WALK end

local function terrainActive()
  return hasRaycast and (walkMode() or cfg.terrainAlways)
end

-- Keep the camera at the same height above the ground as you walk over hills,
-- kerbs and banking, and never let it go under the surface.
local function followTerrain(tpos, dt)
  -- riding in/with a car the camera is rigidly mounted: no terrain logic
  if rigMode ~= 'world' then return tpos end
  local active = terrainActive()
  if active ~= terrainWasActive then groundPrev = nil end
  terrainWasActive = active
  if not active then return tpos end
  local ref = groundPrev or (tpos.y - 0.3)
  local stepUp = groundPrev and 2.0 or 0.6
  local ok, g = pcall(hc.groundAt, raycast, tpos.x, tpos.z, ref, stepUp, 100)
  if not ok or not g then return tpos end -- off the track surface: keep the last height
  groundRaw = g
  local gF = groundPrev and (groundPrev + (g - groundPrev) * hc.smoothK(dt, 0.08)) or g
  -- In follow-car mode the anchor already rides up and down with the car, so
  -- only the never-below-ground clamp applies (following the ground as well
  -- would count every hill twice).
  if groundPrev then
    local dy = gF - groundPrev
    if dy ~= 0 then
      moveAnchor(hc.v(0, dy, 0))
      tpos = hc.add(tpos, hc.v(0, dy, 0))
    end
  end
  groundPrev = gF
  local floor = g + MIN_CLEARANCE
  if tpos.y < floor then
    local lift = floor - tpos.y
    moveAnchor(hc.v(0, lift, 0))
    tpos = hc.add(tpos, hc.v(0, lift, 0))
  end
  return tpos
end

local function applyToCamera(pos, look, up, fov)
  local t = cam.transform
  local l = hc.scale(look, lookSign)
  t.position:set(pos.x, pos.y, pos.z)
  t.look:set(l.x, l.y, l.z)
  t.up:set(up.x, up.y, up.z)
  -- Let CSP derive the side vector with its own convention (v1 computed it
  -- here and could get the sign wrong, mirroring the picture).
  cam:normalize()
  local side = vec(t.side)
  local d = hc.dot(side, hc.cross(up, l))
  sideObserved = d > 0 and 1 or (d < 0 and -1 or 0)
  cam.fov = fov
end

local function updateCamera(dt)
  if not cam then return end
  if not cam:active() then
    cam.disposed = true -- you picked another camera: leave AC in it
    setError(3, 'Handheld released: AC switched to another camera (camera key pressed?)')
    cam, phase, cur, curFov = nil, 'idle', nil, nil
    return
  end

  if phase == 'probe' then
    cam.ownShare = 0
    probeFrames = probeFrames + 1
    -- at least 2 frames so AC has rendered its own camera once more
    if (probeFrames >= 2 and probeConventions()) or probeFrames >= 10 then
      if cfg.lookOverride ~= 0 then lookSign = cfg.lookOverride end
      phase = 'in'
    end
    return
  end

  if not sample then
    -- nothing to show yet: keep AC's camera until the phone data arrives
    cam.ownShare = 0
    if phase == 'out' then releaseNow() end
    return
  end

  -- rig frame for this frame (world, or the car right now)
  local F, mode = currentRig()
  if rigMode ~= nil and mode ~= rigMode then
    -- follow-car switched on/off while engaged: carry the camera over unchanged
    if cur then
      cur.pos = hc.worldToFrame(F, hc.frameToWorld(rigF, cur.pos))
      cur.look = hc.worldToFrameDir(F, hc.frameToWorldDir(rigF, cur.look))
      cur.up = hc.worldToFrameDir(F, hc.frameToWorldDir(rigF, cur.up))
    end
    needAnchor = true
    anchor0 = nil
    groundPrev = nil
  end
  rigF, rigMode = F, mode

  if needAnchor then buildAnchor(sample) end

  -- walk mode: the phone's shutter joystick moves the whole rig. The speed
  -- eases in and out (walkSmoothing) instead of following the stick instantly.
  walking = false
  local target = hc.v(0, 0, 0)
  if walkMode() and not frozen and cur and heartbeatAge < STICK_TIMEOUT then
    target = hc.walkStep(cur.look, cur.up, sample.joyX or 0, sample.joyY or 0, cfg.walkSpeed, 1, mirror())
  end
  if frozen or not cur then
    walkVel = hc.v(0, 0, 0) -- the freeze clutch stops at once
  else
    local tau = math.max(0, cfg.walkSmoothing)
    walkVel = hc.approachVelocity(walkVel, target, dt, tau, tau * 0.7)
  end
  local walkSpeedNow = hc.len(walkVel)
  if walkSpeedNow > 0 then
    moveAnchor(hc.scale(walkVel, dt))
    walking = walkSpeedNow > 0.05
    bobPhase = (bobPhase + 2 * math.pi * hc.cadence(walkSpeedNow) * dt) % (4 * math.pi)
  end

  local tpos, tlook, tup = hc.toWorld(anchor, sample, mirror())
  tpos = followTerrain(tpos, dt)

  local targetFov = cfg.fov
  if cfg.zoomFromPhone then
    if (sample.vfAspect or 0) > 0 then
      -- phone app 4.2: the game frame covers exactly what the phone shows at
      -- this lens (Camera-app scale, whole screen from 1x up), portrait or landscape
      targetFov = hc.fovForView(24 * (sample.zoom or 1), sample.vfAspect, sample.viewOrientation == 1, gameAspect())
    else
      targetFov = hc.fovForZoom(cfg.fov, sample.zoom or 1)
    end
  end
  curFov = curFov and (curFov + (targetFov - curFov) * hc.smoothK(dt, 0.12)) or targetFov

  if not cur then
    cur = { pos = tpos, look = tlook, up = tup }
  elseif not frozen then
    local tau = cfg.smoothing
    if tempSmoothingTime > 0 then
      tempSmoothingTime = tempSmoothingTime - dt
      tau = math.max(tau, tempSmoothing)
    end
    effectiveSmoothing = tau
    local k = hc.smoothK(dt, tau)
    cur.pos = hc.lerp(cur.pos, tpos, k)
    cur.look, cur.up = hc.orthonormal(hc.lerp(cur.look, tlook, k), hc.lerp(cur.up, tup, k))
  end

  -- head bob (walk mode): added to what is shown only, never to the rig itself
  local showPos, showUp = cur.pos, cur.up
  if walkSpeedNow > 0 and cfg.headBob > 0 then
    local vert, side, roll = hc.headBob(bobPhase, walkSpeedNow, cfg.headBob)
    local right = hc.rightOf(hc.headingOf(cur.look, cur.up), mirror())
    showPos = hc.add(cur.pos, hc.add(hc.v(0, vert, 0), hc.scale(right, side)))
    showUp = hc.normalize(hc.add(hc.scale(cur.up, math.cos(roll)), hc.scale(hc.cross(cur.look, cur.up), math.sin(roll))), cur.up)
  end
  -- live view: which pose this frame shows, and how the shown view differs
  -- from that pose's target (smoothing, bob) - the phone timewarps from it
  renderHb = sample.heartbeat
  renderRot = { hc.viewRotation(tlook, tup, cur.look, showUp, mirror()) }

  local bt = math.max(0.01, cfg.blendTime)
  if phase == 'in' then
    share = math.min(1, share + dt / bt)
    if share >= 1 then phase = 'live' end
  elseif phase == 'out' then
    share = math.max(0, share - dt / bt)
    if share <= 0 then
      cam.ownShare = 0
      releaseNow()
      return
    end
  end
  -- rig frame -> world, with the car's pose of this update (the free camera
  -- is moved in the same update, so a car-mounted camera stays on the car)
  applyToCamera(hc.frameToWorld(rigF, showPos), hc.frameToWorldDir(rigF, cur.look),
    hc.frameToWorldDir(rigF, showUp), curFov)
  appliedCount = appliedCount + 1
  cam.ownShare = share
end

-- ---------------------------------------------------------------- hotkeys
local function makeButton(id, key)
  local ok, btn = pcall(ac.ControlButton, id, { keyboard = { key = key, ctrl = true, shift = true } })
  if ok then return btn end
  ac.log('AcHandCam: ControlButton unavailable (' .. tostring(btn) .. '), use the app window')
  return nil
end

local btnToggle = makeButton('AcHandCam/Engage or release', ui.KeyIndex.H)
local btnAnchor = makeButton('AcHandCam/Recenter', ui.KeyIndex.R)
local btnFreeze = makeButton('AcHandCam/Freeze', ui.KeyIndex.F)
local btnPanic = makeButton('AcHandCam/Emergency release', ui.KeyIndex.X)

local function pressed(b) return b ~= nil and b:pressed() end

-- ------------------------------------------------------------------ update
function script.update(dt)
  if dt <= 0 then dt = 1 / 60 end
  fps = fps + (1 / dt - fps) * 0.05

  -- receiver link
  if not pose then
    poseRetry = poseRetry - dt
    if poseRetry <= 0 then
      poseRetry = 1
      openPose()
    end
  end
  local s, valid = readSample()
  if s then
    if s.heartbeat ~= lastHeartbeat then
      lastHeartbeat, heartbeatAge = s.heartbeat, 0
    else
      heartbeatAge = heartbeatAge + dt
    end
    if valid then
      if s.generation ~= lastGeneration then
        if lastGeneration ~= -1 then needAnchor = true end
        lastGeneration = s.generation
      end
      if not frozen then
        sample = s
      elseif sample then
        -- frozen: keep the pose, but zoom/mode/stick still follow the phone
        sample.zoom, sample.mode, sample.joyX, sample.joyY = s.zoom, s.mode, s.joyX, s.joyY
      end
      if sample then
        sample.state, sample.rxHz, sample.loss, sample.latency = s.state, s.rxHz, s.loss, s.latency
        sample.tracking = s.tracking
      end
    elseif sample then
      sample.state = s.state
      sample.joyX, sample.joyY = 0, 0
    end
  else
    heartbeatAge = heartbeatAge + dt
  end

  if pressed(btnPanic) then releaseNow() end
  if pressed(btnToggle) then
    if cam then disengage() else engage() end
  end
  if pressed(btnAnchor) then requestRecenter() end
  if pressed(btnFreeze) then
    frozen = not frozen
    if not frozen then needAnchor = true end
  end

  updateCamera(dt)
  if cam and cam.free then cam:flush() end

  if status then
    heartbeatOut = (heartbeatOut + 1) % 4294967296
    status.magic = hc.STATUS_MAGIC
    status.version = hc.STATUS_LAYOUT_VERSION
    status.heartbeat = heartbeatOut
    status.engaged = cam and 1 or 0
    status.grabbed = (cam and share > 0) and 1 or 0
    status.lastGeneration = math.max(0, lastGeneration)
    status.appliedCount = appliedCount % 4294967296
    status.errorCode = errorCode
    status.fps = fps
    status.lookSign = lookSign
    status.sideSign = sideObserved
    status.recenterRequests = recenterRequests
  end
  if view then
    viewFrame = (viewFrame + 1) % 4294967296
    view.magic = hc.VIEW_MAGIC
    view.version = hc.VIEW_LAYOUT_VERSION
    view.frame = viewFrame
    -- live = the picture follows the phone right now (not blending, frozen
    -- or holding), so the phone may timewarp it
    view.live = (cam and phase == 'live' and not frozen and sample and sample.state == 1) and 1 or 0
    view.fovV = curFov or cfg.fov
    view.smoothing = effectiveSmoothing
    view.poseHeartbeat = renderHb or 0
    if renderRot and renderRot[4] == renderRot[4] then
      view.hasRot = 1
      view.rx, view.ry, view.rz, view.rw = renderRot[1], renderRot[2], renderRot[3], renderRot[4]
    else
      view.hasRot = 0
    end
  end
end

ac.onRelease(function() releaseNow() end)

-- for the automated tests (ac/tests/test_app_harness.lua)
script.__debugCamera = function() return cam end

-- --------------------------------------------------------------------- UI
local colOk, colWarn, colBad = rgbm(0.3, 0.9, 0.4, 1), rgbm(1, 0.7, 0.2, 1), rgbm(1, 0.35, 0.3, 1)

-- 4.2 renamed the app (HandheldCam -> AcHandCam): two copies would both
-- react to the hotkeys, so warn if the old folder is still installed.
local oldAppInstalled = false
pcall(function()
  oldAppInstalled = io.dirExists(ac.getFolder(ac.FolderID.Root) .. '/apps/lua/HandheldCam')
end)

local function stateLine()
  if not pose then return 'Receiver not found - start the PC receiver', colBad end
  if heartbeatAge > RECEIVER_TIMEOUT then return 'Receiver not responding', colBad end
  if not sample then return 'Receiver running - waiting for the phone', colWarn end
  local st = sample.state or 0
  local name = hc.STATE_NAMES[st] or ('state ' .. tostring(st))
  if frozen then name = 'FROZEN in AC (Ctrl+Shift+F)' end
  return name, (st == 1 or st == 6) and not frozen and colOk or colWarn
end

local function handednessText()
  if cfg.handedness == 2 then return 'normal (forced)' end
  if cfg.handedness == 3 then return 'mirrored (forced)' end
  if detectedMirror == nil then return 'auto - not measured yet (engage near a car)' end
  return 'auto - measured from car wheels: ' .. (detectedMirror and 'mirrored' or 'normal')
end

function script.windowMain(dt)
  local text, col = stateLine()
  ui.textColored(text, col)
  if sample and sample.rxHz then
    local lat = (sample.latency and sample.latency >= 0) and string.format('~%.0f ms', sample.latency) or 'n/a'
    ui.text(string.format('Phone: %.0f Hz, loss %.1f%%, capture->PC %s', sample.rxHz, sample.loss or 0, lat))
    ui.text(string.format('Mode: %s%s   Zoom: %.1fx   FOV: %.1f deg',
      walkMode() and 'WALK' or 'HANDHELD', walking and ' (moving)' or '', sample.zoom or 1, curFov or cfg.fov))
    if terrainActive() then
      ui.text(groundRaw and string.format('Terrain: following (ground at %.2f m)', groundRaw) or 'Terrain: no ground found here')
    elseif (walkMode() or cfg.terrainAlways) and not hasRaycast then
      ui.textColored('Terrain following unavailable: physics.raycastTrack missing in this CSP', colWarn)
    end
  end
  ui.text(cam and string.format('Camera: %s (%.0f%%)', phase, share * 100) or 'Camera: AC (not engaged)')
  if errorText ~= '' then ui.textColored(errorText, colBad) end
  if oldAppInstalled then
    ui.textColored('The old "HandheldCam" app is still installed: delete assettocorsa\\apps\\lua\\HandheldCam', colBad)
  end
  ui.separator()

  if cam then
    if ui.button('Release camera (Ctrl+Shift+H)') then disengage() end
  else
    if ui.button('Engage handheld camera (Ctrl+Shift+H)') then engage() end
  end
  ui.sameLine()
  if ui.button('EMERGENCY RELEASE') then releaseNow() end
  if ui.button('Recenter (Ctrl+Shift+R)') then requestRecenter() end
  ui.sameLine()
  if ui.button(frozen and 'Unfreeze (Ctrl+Shift+F)' or 'Freeze (Ctrl+Shift+F)') then
    frozen = not frozen
    if not frozen then needAnchor = true end
  end
  ui.sameLine()
  if ui.button('Back to start point') then resetToStart() end
  ui.separator()

  local v, changed
  if ui.checkbox('Zoom from phone', cfg.zoomFromPhone) then cfg.zoomFromPhone = not cfg.zoomFromPhone end
  v, changed = ui.slider('##fov', cfg.fov, 5, 100,
    cfg.zoomFromPhone and '1x vertical FOV (phone app before v4): %.1f deg' or 'Vertical FOV: %.1f deg')
  if changed then cfg.fov = v end
  v, changed = ui.slider('##walk', cfg.walkSpeed, 0.2, 8, 'Walk speed (full stick): %.1f m/s')
  if changed then cfg.walkSpeed = v end
  v, changed = ui.slider('##walksmooth', cfg.walkSmoothing, 0, 1.5, 'Walk start/stop smoothing: %.2f s')
  if changed then cfg.walkSmoothing = v end
  v, changed = ui.slider('##bob', cfg.headBob, 0, 2, 'Head bob: %.1f (0 = off, 1 = subtle)')
  if changed then cfg.headBob = v end
  if ui.checkbox('Keep above ground in handheld mode too', cfg.terrainAlways) then
    cfg.terrainAlways = not cfg.terrainAlways
  end
  v, changed = ui.slider('##smooth', cfg.smoothing, 0, 0.3, 'Render smoothing: %.3f s')
  if changed then cfg.smoothing = v end
  v, changed = ui.slider('##blend', cfg.blendTime, 0.05, 2, 'Engage/release blend: %.2f s')
  if changed then cfg.blendTime = v end
  if ui.checkbox('Follow focused car (ride with it: in-car / chase shots)', cfg.followCar) then
    cfg.followCar = not cfg.followCar
  end
  if cfg.followCar then
    ui.text('  Car pose:')
    ui.sameLine()
    if ui.radioButton('Drawn body', cfg.followSource ~= 3) then cfg.followSource = 2 end
    ui.sameLine()
    if ui.radioButton('Physics', cfg.followSource == 3) then cfg.followSource = 3 end
    if ui.checkbox('  ...also tilt with the car (rigid mount)', cfg.followTilt) then cfg.followTilt = not cfg.followTilt end
  end

  ui.separator()
  ui.text('Left/right: ' .. handednessText())
  local h = ui.combo('##hand', cfg.handedness, ui.ComboFlags.None, { 'Auto (from car wheels)', 'Force normal', 'Force mirrored' })
  if type(h) == 'number' and h ~= cfg.handedness then
    cfg.handedness = h
    needAnchor = true
  end
  if ui.button('Measure left/right again') then detectHandedness() needAnchor = true end

  if btnToggle and btnToggle.control then
    ui.separator()
    ui.text('Key bindings:')
    for _, b in ipairs({ { 'Engage/release', btnToggle }, { 'Recenter', btnAnchor }, { 'Freeze', btnFreeze },
      { 'Emergency release', btnPanic } }) do
      if b[2] then
        ui.text(b[1])
        ui.sameLine(150)
        b[2]:control(vec2(160, 0))
      end
    end
  end
end
