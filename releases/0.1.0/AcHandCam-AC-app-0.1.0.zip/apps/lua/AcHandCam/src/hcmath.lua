--[[
  Pure maths for the AcHandCam app. No CSP globals are used here so this
  file can be unit tested with plain LuaJIT (see ac/tests/test_hcmath.lua).
  Vectors are plain tables {x=, y=, z=}.

  Frames
  ------
  Filming frame (F): what the PC receiver sends. Components are
      x = right, y = up, z = forward (metres for position, unit vectors for
      the camera's forward and up directions).
  AC world: +Y up. Horizontal "right" of a forward vector F is
      right = cross(Y, F)
  i.e. left = cross(F, Y). This matches CSP's own AI spline editor
  (app-csp-defaults/AISplineEditor/AISpline.lua: sideLeft = pos + cross(forward, up) * width).
  If your build turns out to be mirrored, the app's "Mirror left/right" option
  flips it (mirror = true -> right = -cross(Y, F)).

  Anchor: {pos, fwd} where fwd is a horizontal unit vector. The filming frame
  is mapped into the world as
      world(v) = anchor.pos + right(anchor.fwd) * v.x + Y * v.y + anchor.fwd * v.z
  and directions use the same map without the translation.
]]

local M = {}

-- Shared-memory layouts. Must match receiver/handheld_receiver/shm.py
-- (a Python test compares these strings, a LuaJIT test checks the offsets).
M.POSE_LAYOUT = 'uint32_t magic; uint32_t version; uint32_t seqBegin; uint32_t heartbeat; '
  .. 'int32_t outState; uint32_t flags; uint32_t generation; uint32_t trackingState; '
  .. 'float px; float py; float pz; float fx; float fy; float fz; float ux; float uy; float uz; '
  .. 'float latencyMs; float rxHz; float lossPct; '
  .. 'float zoom; float joyX; float joyY; uint32_t mode; '
  .. 'uint32_t viewOrientation; float vfAspect; uint32_t seqEnd;'
M.STATUS_LAYOUT = 'uint32_t magic; uint32_t version; uint32_t heartbeat; uint32_t engaged; '
  .. 'uint32_t grabbed; uint32_t lastGeneration; uint32_t appliedCount; int32_t errorCode; '
  .. 'float fps; float lookSign; float sideSign; uint32_t recenterRequests;'
-- What the live view needs for timewarp (written every frame). v2 (4.1):
-- the heartbeat of the pose this frame was rendered from and the rotation from
-- that pose's target to what is really shown (render smoothing, head bob).
M.VIEW_LAYOUT = 'uint32_t magic; uint32_t version; uint32_t frame; uint32_t live; '
  .. 'float fovV; float smoothing; uint32_t poseHeartbeat; uint32_t hasRot; '
  .. 'float rx; float ry; float rz; float rw;'
M.POSE_MAGIC = 0x31434D48
M.STATUS_MAGIC = 0x31534D48
M.POSE_LAYOUT_VERSION = 3
M.STATUS_LAYOUT_VERSION = 1
M.VIEW_MAGIC = 0x31564D48
M.VIEW_LAYOUT_VERSION = 2
M.MODE_HANDHELD, M.MODE_WALK = 0, 1

M.STATE_NAMES = {
  [0] = 'waiting for phone', [1] = 'live', [2] = 'holding (tracking lost)', [3] = 'frozen (phone/receiver)',
  [4] = 'paused', [5] = 'holding (no packets)', [6] = 'playing recorded path',
}

local sqrt, abs, cos, sin, atan2 = math.sqrt, math.abs, math.cos, math.sin, math.atan2

function M.v(x, y, z) return { x = x, y = y, z = z } end
function M.add(a, b) return M.v(a.x + b.x, a.y + b.y, a.z + b.z) end
function M.sub(a, b) return M.v(a.x - b.x, a.y - b.y, a.z - b.z) end
function M.scale(a, s) return M.v(a.x * s, a.y * s, a.z * s) end
function M.dot(a, b) return a.x * b.x + a.y * b.y + a.z * b.z end
function M.cross(a, b)
  return M.v(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x)
end
function M.len(a) return sqrt(M.dot(a, a)) end
function M.normalize(a, fallback)
  local l = M.len(a)
  if l < 1e-9 then return fallback end
  return M.scale(a, 1 / l)
end
function M.lerp(a, b, t) return M.v(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, a.z + (b.z - a.z) * t) end
function M.isFinite(a)
  return a.x == a.x and a.y == a.y and a.z == a.z
    and abs(a.x) < 1e30 and abs(a.y) < 1e30 and abs(a.z) < 1e30
end

M.Y = M.v(0, 1, 0)

local function horizontal(a)
  return M.normalize(M.v(a.x, 0, a.z), nil)
end
M.horizontal = horizontal

--- Right-hand horizontal vector for a horizontal forward vector (AC convention).
function M.rightOf(fwd, mirror)
  local r = M.cross(M.Y, fwd)
  if mirror then r = M.scale(r, -1) end
  return r
end

--- Horizontal heading of a camera (works when looking straight up/down).
function M.headingOf(look, up)
  local h = horizontal(look)
  if h and M.len(M.v(look.x, 0, look.z)) > 0.05 then return h end
  local hu = horizontal(up)
  if hu then
    if look.y < 0 then return hu end
    return M.scale(hu, -1)
  end
  return M.v(0, 0, 1)
end

--- Heading angle of a filming-frame camera, measured from +forward towards +right.
function M.filmHeading(f, u)
  if f.x * f.x + f.z * f.z > 0.0025 then return atan2(f.x, f.z) end
  if f.y < 0 then return atan2(u.x, u.z) end
  return atan2(-u.x, -u.z)
end

--- Map a filming-frame vector into world directions (no translation).
function M.dir(anchor, v, mirror)
  local r = M.rightOf(anchor.fwd, mirror)
  return M.v(
    r.x * v.x + anchor.fwd.x * v.z,
    v.y + r.y * v.x + anchor.fwd.y * v.z,
    r.z * v.x + anchor.fwd.z * v.z)
end

--- Full camera pose in world space for a sample {p, f, u} (filming frame).
function M.toWorld(anchor, s, mirror)
  local pos = M.add(anchor.pos, M.dir(anchor, s.p, mirror))
  local look = M.normalize(M.dir(anchor, s.f, mirror), M.v(0, 0, 1))
  local up = M.normalize(M.dir(anchor, s.u, mirror), M.Y)
  return pos, look, up
end

--- Build an anchor so that the sample maps exactly onto the current camera
--- position and horizontal heading (pitch/roll come from the phone's gravity).
function M.makeAnchor(camPos, camLook, camUp, s, mirror)
  local fc = M.headingOf(camLook, camUp)
  local rc = M.rightOf(fc, mirror)
  local a = M.filmHeading(s.f, s.u)
  -- rotate the camera heading back by the sample's heading angle (towards -right)
  local fwd = M.normalize(M.sub(M.scale(fc, cos(a)), M.scale(rc, sin(a))), fc)
  local anchor = { pos = M.v(0, 0, 0), fwd = fwd }
  anchor.pos = M.sub(camPos, M.dir(anchor, s.p, mirror))
  return anchor
end

--- Express an anchor relative to a car (heading-only frame) and back.
function M.toCarLocal(anchor, carPos, carLook, mirror)
  local h = M.headingOf(carLook, M.Y)
  local r = M.rightOf(h, mirror)
  local d = M.sub(anchor.pos, carPos)
  return {
    p = M.v(M.dot(d, r), d.y, M.dot(d, h)),
    a = atan2(M.dot(anchor.fwd, r), M.dot(anchor.fwd, h)),
  }
end

function M.fromCarLocal(loc, carPos, carLook, mirror)
  local h = M.headingOf(carLook, M.Y)
  local r = M.rightOf(h, mirror)
  local pos = M.add(carPos, M.add(M.add(M.scale(r, loc.p.x), M.scale(M.Y, loc.p.y)), M.scale(h, loc.p.z)))
  local fwd = M.normalize(M.add(M.scale(h, cos(loc.a)), M.scale(r, sin(loc.a))), h)
  return { pos = pos, fwd = fwd }
end

-- ---------------------------------------------------------------- v4 rig frames
-- Everything the app smooths and anchors lives in a "rig frame": the world,
-- or (follow-car mode) the car itself. Only when the camera is applied is it
-- turned into world coordinates, using the car's pose of that very frame, so
-- the camera is carried rigidly by the car - no lag, no drifting backwards.
-- Axes: r = cross(u, f) (a proper rotation; identity = world X, Y, Z).
M.WORLD = { o = M.v(0, 0, 0), r = M.v(1, 0, 0), u = M.v(0, 1, 0), f = M.v(0, 0, 1) }

function M.frame(origin, look, up)
  local f = M.normalize(look, M.v(0, 0, 1))
  local u = M.normalize(M.sub(up, M.scale(f, M.dot(up, f))), M.Y)
  return { o = origin, r = M.cross(u, f), u = u, f = f }
end

function M.frameToWorldDir(F, v)
  return M.add(M.add(M.scale(F.r, v.x), M.scale(F.u, v.y)), M.scale(F.f, v.z))
end
function M.frameToWorld(F, p) return M.add(F.o, M.frameToWorldDir(F, p)) end
function M.worldToFrameDir(F, v) return M.v(M.dot(v, F.r), M.dot(v, F.u), M.dot(v, F.f)) end
function M.worldToFrame(F, p) return M.worldToFrameDir(F, M.sub(p, F.o)) end

-- ---------------------------------------------------------------- v4 lenses
--- iPhone-style lens model. The "24 mm" of the main camera is a 35 mm
--- equivalent defined on the 4:3 photo diagonal (43.27 mm), so the sensor's
--- long side is 34.6 mm; video uses the full width. Same formula as
--- receiver/handheld_receiver/timewarp.py game_vfov_for_lens().
M.SENSOR_HALF_LONG_MM = 17.3

--- Vertical FOV (deg) AC must render so the phone's viewfinder for this lens
--- (aspect = long/short side, portrait or landscape) fits the game frame.
function M.fovForLens(focalMm, vfAspect, portrait, gameAspect)
  local tLong = M.SENSOR_HALF_LONG_MM / math.max(1, focalMm)
  local tShort = tLong / math.max(1, vfAspect)
  local tvx, tvy
  if portrait then tvx, tvy = tShort, tLong else tvx, tvy = tLong, tShort end
  local tgy = math.max(tvy, tvx / math.max(0.1, gameAspect))
  return math.deg(2 * math.atan(tgy))
end

--- Quaternion (x, y, z, w) of a rotation matrix m[row][col] (1-based).
function M.quatFromMatrix(m)
  local tr = m[1][1] + m[2][2] + m[3][3]
  local x, y, z, w
  if tr > 0 then
    local s = math.sqrt(tr + 1) * 2
    w = 0.25 * s
    x = (m[3][2] - m[2][3]) / s
    y = (m[1][3] - m[3][1]) / s
    z = (m[2][1] - m[1][2]) / s
  elseif m[1][1] > m[2][2] and m[1][1] > m[3][3] then
    local s = math.sqrt(1 + m[1][1] - m[2][2] - m[3][3]) * 2
    w = (m[3][2] - m[2][3]) / s
    x = 0.25 * s
    y = (m[1][2] + m[2][1]) / s
    z = (m[1][3] + m[3][1]) / s
  elseif m[2][2] > m[3][3] then
    local s = math.sqrt(1 + m[2][2] - m[1][1] - m[3][3]) * 2
    w = (m[1][3] - m[3][1]) / s
    x = (m[1][2] + m[2][1]) / s
    y = 0.25 * s
    z = (m[2][3] + m[3][2]) / s
  else
    local s = math.sqrt(1 + m[3][3] - m[1][1] - m[2][2]) * 2
    w = (m[2][1] - m[1][2]) / s
    x = (m[1][3] + m[3][1]) / s
    y = (m[2][3] + m[3][2]) / s
    z = 0.25 * s
  end
  local n = math.sqrt(x * x + y * y + z * z + w * w)
  if w < 0 then n = -n end
  return x / n, y / n, z / n, w / n
end

--- Camera-local rotation (x = screen right, y = up, z = back, as the phone's
--- timewarp uses) taking the target view (tLook, tUp) to the view actually
--- shown (sLook, sUp). Screen-right follows AC's handedness (`mirror`).
function M.viewRotation(tLook, tUp, sLook, sUp, mirror)
  local function basis(look, up)
    local l, u = M.orthonormal(look, up)
    local r = M.cross(u, l)
    if mirror then r = M.scale(r, -1) end
    return { r, u, M.scale(l, -1) }
  end
  local a, b = basis(tLook, tUp), basis(sLook, sUp)
  local m = {}
  for i = 1, 3 do
    m[i] = {}
    for j = 1, 3 do m[i][j] = M.dot(a[i], b[j]) end
  end
  return M.quatFromMatrix(m)
end

--- 4.2: how much of the phone's screen the picture fills, by focal length:
--- 0 = only the 4:3 sensor area (the .5 lens, like the Camera app), 1 = the
--- whole screen (1x and longer). Eases in between 20 and 24 mm.
function M.viewCoverage(focalMm)
  local t = math.min(1, math.max(0, (focalMm - 20) / 4))
  return t * t * (3 - 2 * t)
end

--- 4.2: vertical FOV (deg) AC renders so its 16:9 frame covers exactly what
--- the phone shows: the screen's short side is the 4:3 sensor's short side at
--- this focal length (the Camera app's scale); the long side runs to the
--- screen's edge (screenAspect = long/short) once the lens fills the screen.
--- Same as receiver/handheld_receiver/timewarp.py game_vfov_for_view().
function M.fovForView(focalMm, screenAspect, portrait, gameAspect)
  local tShort = M.SENSOR_HALF_LONG_MM / math.max(1, focalMm) * 0.75
  local c = M.viewCoverage(focalMm)
  local a = math.max(4 / 3, screenAspect or 4 / 3)
  local tLong = tShort * ((4 / 3) * (1 - c) + a * c)
  local ex, ey
  if portrait then ex, ey = tShort, tLong else ex, ey = tLong, tShort end
  local tgy = math.max(ey, ex / math.max(0.1, gameAspect))
  return math.deg(2 * math.atan(tgy))
end

--- Re-orthonormalise look/up (keeps look, fixes up).
function M.orthonormal(look, up)
  local l = M.normalize(look, M.v(0, 0, 1))
  local u = M.sub(up, M.scale(l, M.dot(up, l)))
  u = M.normalize(u, nil)
  if not u then
    u = M.normalize(M.sub(M.Y, M.scale(l, l.y)), M.v(1, 0, 0))
  end
  return l, u
end

--- Frame-rate independent exponential smoothing factor.
function M.smoothK(dt, tau)
  if tau <= 1e-4 then return 1 end
  return 1 - math.exp(-dt / tau)
end

-- ------------------------------------------------------------------ v2

--- Vertical FOV (degrees) for a phone zoom factor, given the 1x vertical FOV.
--- Matches a real lens: zoom 2 halves tan(fov/2), it does not halve the angle.
function M.fovForZoom(baseFovDeg, zoom)
  zoom = math.max(0.1, zoom or 1)
  local t = math.tan(math.rad(baseFovDeg) / 2) / zoom
  return math.deg(2 * math.atan(t))
end

--- Joystick response: dead zone, then a curve that gives fine control near the
--- centre and full speed at the edge. Returns the shaped (x, y).
function M.shapeStick(x, y, deadzone, power)
  deadzone, power = deadzone or 0.08, power or 1.6
  local mag = math.sqrt(x * x + y * y)
  if mag <= deadzone then return 0, 0 end
  local m = math.min(1, (mag - deadzone) / (1 - deadzone)) ^ power
  return x / mag * m, y / mag * m
end

--- World-space horizontal displacement for one frame of walking.
--- Stick up walks where the camera is looking (horizontally), right strafes.
function M.walkStep(look, up, jx, jy, speed, dt, mirror)
  local sx, sy = M.shapeStick(jx, jy)
  if sx == 0 and sy == 0 then return M.v(0, 0, 0) end
  local h = M.headingOf(look, up)
  local r = M.rightOf(h, mirror)
  return M.scale(M.add(M.scale(r, sx), M.scale(h, sy)), speed * dt)
end

-- ---------------------------------------------------------------- v3.1

--- Walking velocity that eases towards the stick's target velocity instead of
--- jumping: starting takes ~tauAccel, stopping ~tauDecel (frame-rate independent).
function M.approachVelocity(vel, target, dt, tauAccel, tauDecel)
  local tau = (M.len(target) >= M.len(vel)) and tauAccel or tauDecel
  local out = M.lerp(vel, target, M.smoothK(dt, tau))
  if M.len(target) == 0 and M.len(out) < 1e-3 then return M.v(0, 0, 0) end
  return out
end

--- Steps per second when walking at `speed` m/s (about 1.9 at a normal 1.4 m/s).
function M.cadence(speed)
  return math.max(1.4, math.min(2.8, 1.2 + 0.5 * speed))
end

--- Head bob of a handheld camera while walking. `phase` advances 2*pi per
--- step (keep it running over 4*pi: the sway repeats once per stride, i.e.
--- every two steps). Returns vertical (m), sideways (m) and roll (rad).
--- amount 1 = subtle: ~1.2 cm up/down, ~0.8 cm side to side and ~0.2 deg of
--- roll at 1.4 m/s; it grows with speed (capped) and fades to 0 when stopping.
--- Lowest at heel strike (phase 0), highest mid-step, the sway peaks mid-step.
function M.headBob(phase, speed, amount)
  local s = math.min(math.max(speed, 0) / 1.4, 1.6) * (amount or 1)
  if s <= 0 then return 0, 0, 0 end
  return -0.012 * s * math.cos(phase), 0.008 * s * math.sin(phase * 0.5), 0.004 * s * math.sin(phase * 0.5)
end

--- Ground height under (x, z). The ray starts `stepUp` above the last known
--- ground so it can climb slopes and kerbs but never jumps onto a bridge or
--- roof far overhead. `raycast(pos, dir, len)` returns a distance or -1
--- (CSP: physics.raycastTrack). Returns nil when nothing is hit.
function M.groundAt(raycast, x, z, refY, stepUp, maxDrop)
  stepUp, maxDrop = stepUp or 2, maxDrop or 50
  local y0 = refY + stepUp
  local d = raycast(M.v(x, y0, z), M.v(0, -1, 0), stepUp + maxDrop)
  if not d or d < 0 then return nil end
  return y0 - d
end

--- Which way is "right" in this AC world? Measured physically from the car:
--- front-right wheel minus front-left wheel. Returns true when that is the
--- opposite of cross(Y, forward) (i.e. the mirror setting is needed), false
--- when not, nil when it can't be told (no car, degenerate data).
function M.mirrorFromWheels(carLook, frontLeft, frontRight)
  local h = M.headingOf(carLook, M.Y)
  local across = M.sub(frontRight, frontLeft)
  across = M.v(across.x, 0, across.z)
  if M.len(across) < 0.5 then return nil end
  local s = M.dot(M.cross(M.Y, h), across)
  if math.abs(s) < 0.3 * M.len(across) then return nil end
  return s < 0
end

--- Validate a sample read from shared memory.
function M.validSample(s)
  if not (M.isFinite(s.p) and M.isFinite(s.f) and M.isFinite(s.u)) then return false end
  if abs(M.len(s.f) - 1) > 0.05 or abs(M.len(s.u) - 1) > 0.05 then return false end
  if abs(s.p.x) > 10000 or abs(s.p.y) > 10000 or abs(s.p.z) > 10000 then return false end
  return true
end

return M
