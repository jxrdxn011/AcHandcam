AcHandCam receiver 0.1.0
============================

1. Install Python 3.10 or newer from python.org (tick "Add python.exe to PATH").
2. Double-click run_receiver.bat. Allow it on Private networks if Windows asks.
3. Type the PC address shown at the top of the window into the phone app.

AMD graphics card: in the Live view tab set Backend = native and click Apply.
Other graphics cards: install FFmpeg once (open Command Prompt, run
"winget install Gyan.FFmpeg"), then restart the receiver.

Install guide and help: https://github.com/jxrdxn011/AcHandcam
