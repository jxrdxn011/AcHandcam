@echo off
rem Starts the AcHandCam receiver with its window. No admin rights needed.
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
%PY% -m handheld_receiver %*
if errorlevel 1 pause
